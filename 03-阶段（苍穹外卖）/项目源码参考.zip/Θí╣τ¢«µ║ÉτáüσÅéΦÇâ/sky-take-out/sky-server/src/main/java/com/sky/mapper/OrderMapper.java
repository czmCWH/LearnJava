package com.sky.mapper;


import com.github.pagehelper.Page;
import com.sky.entity.Orders;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface OrderMapper {

    /**
     * 添加订单信息
     * @param orders
     */

    void insert(Orders orders);

    /**
     * 查询所有订单
     * 条件查询订单信息
     * @param orders
     * @return
     */
    Page<Orders> pageQuery(Orders orders);

    /**
     * 查询订单基本信息
     * @param orders
     * @return
     */
    @Select("select * from  orders where id = #{id}")
    Orders select(Orders orders);


    /**
     * 修改订单
     * @param cancelOrder
     */
    @Update("update orders set " +
            "status = #{status} , pay_status = #{payStatus} , cancel_time = #{cancelTime} , cancel_reason = #{cancelReason}" +
            " where id = #{id}")
    void update(Orders cancelOrder);

    /**
     * 根据状态统计订单数量
     * @param status
     */
    @Select("select count(id) from orders where status = #{status}")
    Integer countStatus(Integer status);



    /**
     * 根据订单状态和下单时间查询订单
     *
     * @return
     */
    @Select("select * from orders where status = #{status} and order_time < #{orderTime}")
    List<Orders> getByStatusAndOrderTime(Integer status, LocalDateTime orderTime);


    /**
     *
     * @param orders
     * @return
     */

}
