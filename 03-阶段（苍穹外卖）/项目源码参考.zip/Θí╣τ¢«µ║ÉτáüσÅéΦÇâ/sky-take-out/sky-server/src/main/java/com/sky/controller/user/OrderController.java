package com.sky.controller.user;


import com.sky.dto.OrdersDTO;
import com.sky.dto.OrdersPageQueryDTO;
import com.sky.dto.OrdersPaymentDTO;
import com.sky.dto.OrdersSubmitDTO;
import com.sky.result.PageResult;
import com.sky.result.Result;
import com.sky.service.OrderService;
import com.sky.vo.OrderPaymentVO;
import com.sky.vo.OrderSubmitVO;
import com.sky.vo.OrderVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * 用户订单管理
 */
@Slf4j
@RestController
@RequestMapping("/user/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    /**
     * 用户下单
     * @param ordersSubmitDTO
     * @return
     */
    @PostMapping("/submit")
    public Result<OrderSubmitVO> submit(@RequestBody OrdersSubmitDTO ordersSubmitDTO) {
        log.info("用户下单,参数为:{}", ordersSubmitDTO);
        OrderSubmitVO orderSubmitVO = orderService.submitOrder(ordersSubmitDTO);
        return Result.success(orderSubmitVO);
    }

    /**
     * 历史订单查询
     * @param ordersPageQueryDTO
     * @return
     */
    @GetMapping("/historyOrders")
    public Result<PageResult> pageQuery( OrdersPageQueryDTO ordersPageQueryDTO) {
        log.info("历史订单查询");
        PageResult pageResult = orderService.pageQuery(ordersPageQueryDTO);
        return Result.success(pageResult);
    }


    /**
     * 再来一单
     * @param id
     * @return
     */
    @PostMapping("/repetition/{id}")
    public Result oneMoreOrder(@PathVariable Integer id) {
        log.info("再来一单 :{}",id);
        orderService.oneMoreOrder(id);
        return Result.success();
    }


    /**
     * 用户取消订单
     * @param id
     * @return
     */
    @PutMapping("/cancel/{id}")
    public Result cancelOrder (@PathVariable Integer id) {
        log.info("取消订单:{}",id);
        orderService.cancelOrderByUser(id);
        return Result.success();
    }

    /**
     * 查询订单详情
     * @param id
     * @return
     */
    @GetMapping("/orderDetail/{id}")
    public Result<OrderVO> selectOrders(@PathVariable Integer id){
        log.info("查询订单详情:{}",id);
        OrderVO orderVO = orderService.selectOrders(id);
        return Result.success(orderVO);
    }

    /**
     * 订单支付
     * @param ordersPaymentDTO
     * @return
     */
    /*@PutMapping("/payment")
    public Result<OrderPaymentVO> paymentOrders (@RequestBody OrdersPaymentDTO ordersPaymentDTO) {
        log.info("订单支付:{}",ordersPaymentDTO);
        OrderPaymentVO orderPaymentVO = orderService.paymentOrders(ordersPaymentDTO);
        return Result.success(orderPaymentVO);
    }*/
}
