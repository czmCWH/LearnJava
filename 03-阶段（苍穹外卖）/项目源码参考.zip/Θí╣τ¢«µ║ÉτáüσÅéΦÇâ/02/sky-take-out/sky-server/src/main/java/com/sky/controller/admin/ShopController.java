package com.sky.controller.admin;

import com.sky.result.Result;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

@RestController("AdminShopController")
@Api(tags = "店铺相关接口")
@Slf4j
@RequestMapping("/admin/shop")
public class ShopController {
    @Autowired
    private RedisTemplate redisTemplate;

    //resis的key，店铺营业状态key
    public static final  String SHOP_KEY="SHOP_VALUE";
    /**
     * 设置店铺的营业状态
     *
     * @param status
     * @return
     */
    @PutMapping("/{status}")
    @ApiOperation("设置店铺的营业状态")
    public Result SetStatus(@PathVariable Integer status) {
        log.info("店铺的营业状态：{}", status == 1 ? "营业中" : "打烊中");
        //用redis存店铺状态
        redisTemplate.opsForValue().set(SHOP_KEY, status);
        return Result.success();
    }

    /**
     * 获取店铺的营业状态
     */
    @GetMapping("/status")
    @ApiOperation("获取店铺的营业状态")
    public Result<Integer> GetStatus() {
        Integer status = (Integer) redisTemplate.opsForValue().get(SHOP_KEY);
         if (status == null) {//会报空指针异常
            status = 0; // 默认值或处理逻辑
        }

        log.info("获取店铺的营业状态：{}",status==1?"营业中" : "打烊中");
        return Result.success(status);
    }
}
