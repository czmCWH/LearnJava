package com.czm.d13_genericity_method;

public class Car {
}

class TSL extends Car {
}

class LX extends Car {
}
