package com.czm.d13_genericity_method;

public class Dog {
}
