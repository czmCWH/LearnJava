package com.czm.d8_enum;

public enum Constant2 {
    DOWN, UP, HALF_UP, DEL_LEFT
}
