package com.czm.d8_enum;

public class Constant {
    public static final int DOWN = 1;
    public static final int UP = 2;
    public static final int HALF_UP = 3;
    public static final int DEL_LEFT = 4;

}
