package com.czm.d3_innerClass;

public class Test {
    /*
     1、局部内部类
        局部内部类是定义在在方法中、代码块中、构造器等执行体中

     说明：没什么用，鸡肋API
     */
    public static void main(String[] args) {

    }
}
