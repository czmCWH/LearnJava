package com.czm.d3_innerClass;

public class Outer {
    public void printSlogan() {
        // 1、定义局部内部类
        class A {

        }
    }
}
