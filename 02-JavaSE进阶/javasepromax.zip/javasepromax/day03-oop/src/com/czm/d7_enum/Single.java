package com.czm.d7_enum;

// 单例模式
public enum Single {
    B;
}
