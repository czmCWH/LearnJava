package com.czm.d5_innerClass;

// 通过接口来约束类具备某些功能
public interface Swimming {
    void swim();
}