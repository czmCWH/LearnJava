package com.czm.d5_innerClass;

public class Animal implements Swimming {
    @Override
    public void swim() {
        System.out.println("===动物游泳～");
    }
}

