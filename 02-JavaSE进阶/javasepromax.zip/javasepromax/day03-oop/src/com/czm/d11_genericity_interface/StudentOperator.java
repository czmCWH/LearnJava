package com.czm.d11_genericity_interface;
// 定义学生业务操作类
public class StudentOperator implements Data<Student> {
    @Override
    public void add(Student student) {

    }

    @Override
    public void remove(Student student) {

    }

    @Override
    public void update(Student student) {

    }

    @Override
    public Student getById(int id) {
        return null;
    }
}
