package com.czm.d11_genericity_interface;

public class Teacher {
}
