package com.czm.d11_genericity_interface;

public class Test {
    /*
     1、泛型接口语法
        修饰符 interface 接口名<泛型变量1, 泛型变量2...> {

      注意：类型变量建议用大写的英文字母，常用的有:E、T、K、V等
     */
    public static void main(String[] args) {

    }
}
