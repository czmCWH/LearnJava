package com.czm.d7_map;

public class Test2 {
    /*
     1、LinkedHashMap<K,V> 集合的原理

        底层数据结构依然是基于哈希表实现的，只是每个键值对元素又额外的多了一个双链表的机制记录元素顺序(保证有序)。

        实际上：原来学习的 LinkedHashSet 集合的底层原理就是 LinkedHashMap。

     2、

     */
    public static void main(String[] args) {

    }
}
