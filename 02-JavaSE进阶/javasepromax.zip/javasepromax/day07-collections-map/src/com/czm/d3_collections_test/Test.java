package com.czm.d3_collections_test;

public class Test {
    /*
     1、案例 - 斗地主
        总共54张牌；
        点数：3、4、5、6、7、8、9、10、J、Q、K、A、2
        花色： ♥, ♣, ♦, ♠
        大小王：
        发出51张牌，留3张底牌
     */
    public static void main(String[] args) {
        Room r = new Room();
        r.start();
    }
}
