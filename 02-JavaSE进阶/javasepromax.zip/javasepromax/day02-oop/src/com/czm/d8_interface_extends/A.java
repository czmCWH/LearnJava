package com.czm.d8_interface_extends;

public interface A {
    public void a();
}
