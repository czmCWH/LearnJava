package com.czm.d8_interface_extends;

public interface B {
    public void b();
}
