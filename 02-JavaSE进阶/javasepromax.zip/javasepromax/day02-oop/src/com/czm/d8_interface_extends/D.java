package com.czm.d8_interface_extends;

public interface D extends A, B, C {
    public void d();
}
