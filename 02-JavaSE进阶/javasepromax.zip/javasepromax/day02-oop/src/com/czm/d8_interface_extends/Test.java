package com.czm.d8_interface_extends;

public class Test {
    /*
     1、接口多继承
        a、类与类是单继承的：一个类只能直接继承一个父类。
        b、类与接口是多实现的：一个类可以同时实现多个接口。
        c、接口和接口是多继承的：一个接口可以同时继承多个接口

     2、接口多继承的好处
        便于实现类去实现，避免一个类实现多个接口
     */
    public static void main(String[] args) {

    }
}
