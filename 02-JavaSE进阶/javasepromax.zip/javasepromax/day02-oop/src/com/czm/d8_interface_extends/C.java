package com.czm.d8_interface_extends;

public interface C {
    public void c();
}
