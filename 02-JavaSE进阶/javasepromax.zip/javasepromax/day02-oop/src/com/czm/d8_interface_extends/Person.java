package com.czm.d8_interface_extends;

public class Person implements D {
    @Override
    public void d() {

    }

    @Override
    public void a() {

    }

    @Override
    public void b() {

    }

    @Override
    public void c() {

    }
}
