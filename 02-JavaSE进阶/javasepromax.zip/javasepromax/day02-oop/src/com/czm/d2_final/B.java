package com.czm.d2_final;

// 1、报错
//public class B extends A {
//}

public class B {
    public final void run() {

    }
}