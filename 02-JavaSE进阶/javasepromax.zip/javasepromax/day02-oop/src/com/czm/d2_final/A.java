package com.czm.d2_final;

public final class A {
}
