package com.czm.d2_final;

public class C {
    // 报错
//    @Override
//    public final void run() {
//
//    }
}
