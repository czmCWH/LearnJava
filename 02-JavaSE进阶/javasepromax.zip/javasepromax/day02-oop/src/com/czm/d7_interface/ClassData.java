package com.czm.d7_interface;

public interface ClassData {
    void printAllStudentInfos();
    void printAllStudentAverageScores();
}
