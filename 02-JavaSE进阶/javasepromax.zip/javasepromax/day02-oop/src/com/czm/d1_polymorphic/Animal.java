package com.czm.d1_polymorphic;

import org.w3c.dom.ls.LSOutput;

public class Animal {
    public String name = "动物名称";
    public void cry() {
        System.out.println("---动物发出叫声");
    }
}