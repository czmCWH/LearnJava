package com.czm.d6_interface;

// 定义接口 B
public interface B {
    void eat();
}
