package com.czm.d9_interface_jdk8;

public class Demo implements A {
}
