package com.czm.d5_abstract;

public class Teacher extends Person {
//    public void write() {
//        System.out.println("\t\t\t《我爱中国》");
//        System.out.println("\t中国有56个民族");
//        System.out.println("\t教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！");
//        System.out.println("\t我爱你中国，生活在中国好幸福！");
//    }


    @Override
    public void writeMain() {
        System.out.println("\t教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！教育好学生，为教育强国奋斗！");
    }
}
