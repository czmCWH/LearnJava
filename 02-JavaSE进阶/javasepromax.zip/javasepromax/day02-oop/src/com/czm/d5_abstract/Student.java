package com.czm.d5_abstract;

public class Student extends Person {

//    public void write() {
//        System.out.println("\t\t\t《我爱中国》");
//        System.out.println("\t中国有56个民族");
//        System.out.println("\t好好学习，报效祖国！好好学习，报效祖国！好好学习，报效祖国！");
//        System.out.println("\t我爱你中国，生活在中国好幸福！");
//    }


    @Override
    public void writeMain() {
        System.out.println("\t好好学习，报效祖国！好好学习，报效祖国！好好学习，报效祖国！");
    }
}
