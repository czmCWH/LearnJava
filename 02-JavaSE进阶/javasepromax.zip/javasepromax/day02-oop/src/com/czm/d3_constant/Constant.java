package com.czm.d3_constant;

public class Constant {
    // 定义常量
    public static final String HOST_NAME = "中华民族复兴";
}
