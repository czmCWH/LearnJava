package com.czm.d4_abstract;

public class Cat extends Animal {
    @Override
    public void cry() {
        System.out.println("--- 猫咪，喵喵喵！");
    }
}
