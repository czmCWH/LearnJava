package com.czm.d4_abstract;

public class Dog extends Animal {
    @Override
    public void cry() {
        System.out.println("--- 狗，汪汪汪！");
    }
}
