package com.czm.d9_extends_object;

public class A {
}
