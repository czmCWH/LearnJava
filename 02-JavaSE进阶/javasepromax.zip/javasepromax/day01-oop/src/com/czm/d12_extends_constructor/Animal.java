package com.czm.d12_extends_constructor;

public class Animal {
    public Animal() {
        System.out.println("--- Animal 的无参构造器");
    }

    public Animal(int n) {
        System.out.println("--- Animal 的有参构造器");
    }
}
