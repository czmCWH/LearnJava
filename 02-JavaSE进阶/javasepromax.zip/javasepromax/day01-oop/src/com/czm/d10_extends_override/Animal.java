package com.czm.d10_extends_override;

public class Animal {
    public void run() {
        System.out.println("--- 动物会跑～");
    }
}
