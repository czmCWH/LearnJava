package com.czm.d9_thread_life;

public class Test1 {
    /*
     1、线程的生命周期
        也就是线程从生到死的过程中，经历的各种状态及状态转换。
        理解线程这些状态有利于提升并发编程的理解能力。

     2、Java线程的状态
        Java 总共定义了6种状态，这6种状态都定义在Thread类的内部枚举类中。

     */
    public static void main(String[] args) {

    }
}
