package com.czm.d6_object_stream;

public class Test2 {
    /*
     1、ArrayList 集合已经实现了序列化接口！
        直接操作 ArrayList 对象即可

     */
    public static void main(String[] args) {

    }
}
