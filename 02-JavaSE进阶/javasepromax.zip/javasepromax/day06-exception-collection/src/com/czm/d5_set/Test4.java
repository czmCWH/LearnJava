package com.czm.d5_set;

public class Test4 {
    /*
     1、LinkedHashSet<E> 集合
        它依然是基于哈希表(数组、链表、红黑树)实现的；
        但是，它的每个元素都额外的多了一个双链表的机制记录它前后元素的位置；因此它是有序的。

        牺牲内存，获取效果。

     2、
     */
    public static void main(String[] args) {

    }
}
