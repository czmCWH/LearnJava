package com.czm.d2_Lambda;

// 定义一个抽象类
public abstract class Animal {
    public abstract void run();
}
