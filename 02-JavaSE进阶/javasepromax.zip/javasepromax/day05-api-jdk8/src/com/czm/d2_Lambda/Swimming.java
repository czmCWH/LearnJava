package com.czm.d2_Lambda;

// 定义一个接口
public interface Swimming {
    void swim();
}
